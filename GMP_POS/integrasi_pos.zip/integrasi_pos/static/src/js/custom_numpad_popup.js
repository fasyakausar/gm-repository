/** @odoo-module **/

import { AbstractAwaitablePopup } from "@point_of_sale/app/popup/abstract_awaitable_popup";
import { _t } from "@web/core/l10n/translation";
import { useService } from "@web/core/utils/hooks";
import { useState, useRef, onMounted, onWillUnmount } from "@odoo/owl";
import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";

export class CustomNumpadPopUp extends AbstractAwaitablePopup {
    static template = "integrasi_pos.CustomNumpadPopUp";

    setup() {
        super.setup();
        this.pos = useService("pos");
        this.popup = useService("popup");
        this.notification = useService("notification");
        this.rpc = useService("rpc");
        this.inputRef = useRef("pinInput");

        this.state = useState({
            inputValue: "",
            displayValue: "",
            note: "",
        });

        // Keyboard handler untuk PIN
        this._onKeyDown = (ev) => {
            if (ev.defaultPrevented) return;
            const key = ev.key;
            if (key >= "0" && key <= "9") {
                ev.preventDefault();
                this.addNumber(key);
            } else if (key === "Backspace") {
                ev.preventDefault();
                this.removeLastChar();
            } else if (key === "Enter") {
                ev.preventDefault();
                this.confirmInput();
            } else if (key === "Escape") {
                ev.preventDefault();
                this.cancel();
            }
        };

        onMounted(() => {
            this.inputRef.el?.focus();
            window.addEventListener("keydown", this._onKeyDown);
        });

        onWillUnmount(() => {
            window.removeEventListener("keydown", this._onKeyDown);
        });

        this.handleTyping = (ev) => {
            const input = ev.target.value;
            const lastChar = input.slice(-1);
            if (!/^\d$/.test(lastChar)) return;
            if (this.state.inputValue.length >= 4) return;
            this.state.inputValue += lastChar;
            this.state.displayValue += "*";
        };

        this.handleNoteInput = (ev) => {
            this.state.note = ev.target.value;
        };
    }

    // ─── Numpad: handler utama via data-num ───────────────────────

    /**
     * Handler untuk click (mouse/desktop)
     * Membaca nilai dari attribute data-num pada button
     */
    onNumpadClick(ev) {
        const num = ev.currentTarget.dataset.num;
        if (!num) return;
        if (num === "backspace") {
            this.removeLastChar();
        } else {
            this.addNumber(num);
        }
    }

    /**
     * Handler untuk touchstart (touchscreen)
     * preventDefault() mencegah ghost click yang muncul ~300ms setelah touch
     */
    onNumpadTouch(ev) {
        ev.preventDefault();
        const num = ev.currentTarget.dataset.num;
        if (!num) return;
        if (num === "backspace") {
            this.removeLastChar();
        } else {
            this.addNumber(num);
        }
    }

    // ─── Action buttons touch handlers ───────────────────────────

    onConfirmTouch(ev) {
        ev.preventDefault();
        this.confirmInput();
    }

    onCancelTouch(ev) {
        ev.preventDefault();
        this.cancel();
    }

    // ─── Core logic ───────────────────────────────────────────────

    addNumber(num) {
        if (this.state.inputValue.length >= 4) return;
        this.state.inputValue += num;
        this.state.displayValue += "*";
    }

    onKeyDown(ev) {
        if (ev.key === "Enter") {
            ev.preventDefault();
            this.confirmInput();
        } else if (ev.key === "Escape") {
            ev.preventDefault();
            this.cancel();
        }
    }

    removeLastChar() {
        this.state.inputValue = this.state.inputValue.slice(0, -1);
        this.state.displayValue = this.state.displayValue.slice(0, -1);
    }

    clearInput() {
        this.state.inputValue = "";
        this.state.displayValue = "";
        this.state.note = "";
    }

    async confirmInput() {
        const enteredPin = this.state.inputValue;
        const expectedPin = this.pos.config.manager_pin;

        if (!enteredPin) {
            await this.popup.add(ErrorPopup, {
                title: _t("Invalid Input"),
                body: _t("Please enter a valid PIN."),
            });
            return;
        }

        if (!expectedPin) {
            await this.popup.add(ErrorPopup, {
                title: _t("Configuration Error"),
                body: _t("Manager PIN is not set in POS configuration."),
            });
            return;
        }

        if (enteredPin === expectedPin) {
            try {
                await this.rpc("/pos/log_note/create", {
                    note: this.state.note || "No reason provided",
                });
            } catch (error) {
                console.error("Failed to create log note:", error);
            }

            this.notification.add(_t("PIN Validated Successfully"), { type: "success" });
            this.confirm({ confirmed: true });
        } else {
            await this.popup.add(ErrorPopup, {
                title: _t("Invalid PIN"),
                body: _t("The entered PIN is incorrect. Please try again."),
            });
        }
    }
}