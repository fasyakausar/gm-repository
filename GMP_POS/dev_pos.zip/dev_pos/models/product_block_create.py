from odoo import models, _
from odoo.exceptions import AccessError


class ProductTemplateBlockCreate(models.Model):
    _inherit = 'product.template'

    def check_access_rights(self, operation, raise_exception=True):
        if (operation == 'create'
                and self.env.context.get('block_product_create')
                and not self.env.su):
            if raise_exception:
                raise AccessError(_(
                    "Anda tidak diizinkan membuat produk baru dari sini. "
                    "Silakan pilih produk yang sudah ada."
                ))
            return False
        return super().check_access_rights(operation, raise_exception=raise_exception)


class ProductProductBlockCreate(models.Model):
    _inherit = 'product.product'

    def check_access_rights(self, operation, raise_exception=True):
        if (operation == 'create'
                and self.env.context.get('block_product_create')
                and not self.env.su):
            if raise_exception:
                raise AccessError(_(
                    "Anda tidak diizinkan membuat produk baru dari sini. "
                    "Silakan pilih produk yang sudah ada."
                ))
            return False
        return super().check_access_rights(operation, raise_exception=raise_exception)