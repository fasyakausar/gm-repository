# -*- coding: utf-8 -*-
from odoo import fields, models, api
from datetime import datetime, time
from pytz import UTC
from pytz import timezone

class EndShiftSession(models.Model):
    _name = 'end.shift'
    _rec_name = 'doc_num'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "End Shift Session per Cashier"

    doc_num = fields.Char(string='Shift Number', tracking=True, readonly=True, copy=False)
    cashier_id = fields.Many2one('hr.employee', string='Cashier', tracking=True, required=True)
    session_id = fields.Many2one('pos.session', string='Session', tracking=True, required=True)
    start_date = fields.Datetime(string='Start Date', tracking=True)
    end_date = fields.Datetime(string='End Date', tracking=True)
    modal = fields.Float(string="Modal", tracking=True, default=0.0, help="Modal awal untuk shift ini")
    is_integrated = fields.Boolean(string='Integrated', default=False, readonly=True, tracking=True)
    state = fields.Selection([
        ('opened', 'Opened'),
        ('in_progress', 'In Progress'),
        ('closed', 'Closed'),
        ('finished', 'Finished')
    ], string='Status', default='opened', required=True, readonly=True, copy=False, tracking=True)

    line_ids = fields.One2many('end.shift.line', 'end_shift_id', string='Shift Lines', context={'parent_state': 'state'})

    pos_order_count = fields.Integer(string='POS Orders', compute='_compute_pos_order_count')
    vit_notes = fields.Text(string="Notes", tracking=True, required=True)

    @api.depends('cashier_id', 'session_id')
    def _compute_pos_order_count(self):
        for record in self:
            # Mendapatkan tanggal hari ini dalam waktu lokal server
            start_date_str = fields.Datetime.to_string(self.start_date)
            end_date_str = fields.Datetime.to_string(self.end_date)

            record.pos_order_count = self.env['pos.order'].search_count([
                ('session_id', '=', record.session_id.id),
                ('employee_id', '=', record.cashier_id.id),
                ('state', '=', 'invoiced'),
                ('create_date', '>=', start_date_str),
                ('create_date', '<=', end_date_str)
            ])

    def action_view_pos_orders(self):
        self.ensure_one()
        
        # Menggunakan start_date dan end_date dari record end.shift
        start_date_str = fields.Datetime.to_string(self.start_date)
        end_date_str = fields.Datetime.to_string(self.end_date)

        domain = [
            ('session_id', '=', self.session_id.id),
            ('employee_id', '=', self.cashier_id.id),
            ('state', '=', 'invoiced'),
            ('create_date', '>=', start_date_str),
            ('create_date', '<=', end_date_str)
        ]

        # Untuk debugging
        orders = self.env['pos.order'].search(domain)
        print(f"Jumlah pesanan yang ditemukan: {len(orders)}")
        for order in orders:
            print(f"Order ID: {order.id}, Create Date: {order.create_date}")

        return {
            'name': 'POS Orders',
            'type': 'ir.actions.act_window',
            'res_model': 'pos.order',
            'view_mode': 'tree,form',
            'domain': domain,
            'context': {'create': False}
        }
    
    @api.model
    def create(self, vals):
        # Mengambil sequence untuk document number
        sequence_code = 'end.shift.doc.num'
        doc_num_seq = self.env['ir.sequence'].next_by_code(sequence_code)

        # Mengambil informasi POS dari session
        session = self.env['pos.session'].browse(vals.get('session_id'))
        pos_config = session.config_id

        # Mengambil nama POS
        pos_name = pos_config.name if pos_config else 'UNKNOWN'

        # Membersihkan nama POS dari karakter yang tidak diinginkan
        pos_code = ''.join(e for e in pos_name if e.isalnum()).upper()

        user_tz = timezone(self.env.user.tz or 'UTC')

        # Mendapatkan tanggal dan waktu saat ini dalam zona waktu lokal
        current_datetime = datetime.now(user_tz)
        date_str = current_datetime.strftime("%Y%m%d")
        time_str = current_datetime.strftime("%H%M%S")

        # Membuat doc_num dengan format yang diinginkan
        # vals['doc_num'] = f"{pos_code}/{date_str}/{time_str}/{doc_num_seq}"

        # Set state to 'opened'
        vals['state'] = 'opened'

        # Panggil metode create asli untuk membuat record baru
        result = super(EndShiftSession, self).create(vals)
        return result

    def action_start_progress(self):
        for record in self:
            record.state = 'in_progress'
            record.line_ids.write({'state': 'in_progress'})

    def action_close(self):
        for record in self:
            current_time = fields.Datetime.now()

            # ✅ Update status end.shift dan end.shift.line
            record.write({
                'end_date': current_time,
                'state': 'closed'
            })

            record.line_ids.write({'state': 'closed'})  # ✅ update tanpa hapus
        return {'result': 'success'}


    def action_finish(self):
        for record in self:
            record.state = 'finished'
            record.line_ids.write({'state': 'finished'})
            
            cashier_logs = self.env['pos.cashier.log'].search([
                ('employee_id', '=', record.cashier_id.id),
                ('session_id', '=', record.session_id.id),
                ('state', '!=', 'closed')
            ])
            if cashier_logs:
                cashier_logs.write({'state': 'closed'})
        return {'result': 'success'}

    # def action_reset(self):
    #     for record in self:
    #         record.state = 'opened'
    #         record.line_ids.write({'state': 'opened'})

class EndShiftSessionLine(models.Model):
    _name = 'end.shift.line'
    _description = "End Shift Line Session per Cashier"

    end_shift_id = fields.Many2one('end.shift', string='End Shift Session', required=True, ondelete='cascade')
    payment_date = fields.Datetime(string='Date', tracking=True)
    payment_method_id = fields.Many2one('pos.payment.method', string="Payment Method", tracking=True, required=True)
    amount = fields.Float(string="Amount", tracking=True)
    expected_amount = fields.Float(string="Expected Amount", tracking=True)
    amount_difference = fields.Float(string="Amount Difference", compute='_compute_amount_difference', store=True, tracking=True)
    state = fields.Selection([
        ('opened', 'Opened'),
        ('in_progress', 'In Progress'),
        ('closed', 'Closed'),
        ('finished', 'Finished')
    ], string='Status', default='opened', required=True, readonly=True, copy=False, tracking=True)
            
    @api.depends('amount', 'expected_amount')
    def _compute_amount_difference(self):
        for record in self:
            record.amount_difference = record.amount - record.expected_amount

    @api.model
    def create(self, vals):
        res = super(EndShiftSessionLine, self).create(vals)
        res._compute_amount_difference()
        return res

    def write(self, vals):
        res = super(EndShiftSessionLine, self).write(vals)
        if 'amount' in vals or 'expected_amount' in vals:
            self._compute_amount_difference()
        return res